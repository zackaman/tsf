package com.tsf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TsfApplication {

	public static void main(String[] args) {
		SpringApplication.run(TsfApplication.class, args);
	}

}

